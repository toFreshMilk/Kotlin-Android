package edu.android.and02_simpleapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    /**
     * 이미지의 아이디를 배열로 저장해서 한번에 컨트롤
     */
    private val imageIDS = arrayOf(
        R.drawable.n1,
        R.drawable.n2,
        R.drawable.n3,
        R.drawable.n4,
        R.drawable.n5
    )
    private var curIndex = 0 //현재 인덱스 번호

    //이전 이미지를 생성하는 함수
    private fun showPrevImage() {
        if(curIndex > 0) {
            curIndex --
        } else {
            curIndex = imageIDS.size - 1 //배열의 마지막인덱스
        }
        //이미지의 아이디를 바탕으로 이미지뷰에 리소스를 생성
        imageView.setImageResource(imageIDS[curIndex])
    }


    //다음 이미지를 생성하는 함수
    private fun showNextImage() {
        if(curIndex < imageIDS.size - 1) {
            curIndex ++
        } else {
            curIndex = 0 //배열의 마지막인덱스
        }
        //이미지의 아이디를 바탕으로 이미지뷰에 리소스를 생성
        imageView.setImageResource(imageIDS[curIndex])
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preButton.setOnClickListener {
            println(it)

            showPrevImage()
        }
        nextButton.setOnClickListener {
            showNextImage()
        }
    }
}
