package edu.android.and03_lifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

const val TAG = "edu.android.and03"

class MainActivity : AppCompatActivity() {

    init {
        Log.i(TAG, "메인 엑티비티다 init")
    }

    /**
     * oncreate() : 앱이 처음 실행될 때 ART(Android Run-Time)이 호출하는 메소드
     * - 레이아웃과 위젯 생성, 대부분의 초기화 이루어짐
     * - 화면에 보이지는 않는 상태(invisible)
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i(TAG, "oncreate called")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            val msg = editText.text.toString()
            textView.text = msg
        }
    }

    /**
     * onStart() : onCreate() 이후에 호출되는 생명주기 메소드
     * - 화면에 보이는 상태(visible)
     * - 이벤트 처리는 할 수 없는 상태(not focus)
     * - 시각 요소들을 드로잉 할 때 주로 사용됨
     */
    override fun onStart() {
        Log.i(TAG, "onStrat() called")
        super.onStart()
    }

    /**
     * onResume() : onStart()이후에 호출되는 생명주기 메소드
     * - 화면에 보이는 상태(visible)
     * - 이벤트 처리가 가능한 상태(focus)
     * - 액티비티가 활성화 되었고 입력을 받을 수 있는 상태를 나타냄
     */
    override fun onResume() {
        Log.i(TAG, "onResume() called")
        super.onResume()
    }

    /**
     * onPause() : 앱이 백그라운드로 가거나 종료될때 불리는 메소드
     * - 화면에 보이는 상태(Visible)
     * - 이벤트 처리를 할 수 없는 상태
     */
    override fun onPause() {
        Log.i(TAG, "onPause() called")
        super.onPause()
    }

    /**
     * onStop() : onPause() 이후에 호출되는 생명주기 메소드
     * - 화면에서 보이지 않는 상태(invisible)
     * - 이벤트 처리를 할 수 없는 상태
     * - UI 업데이트나 애니메이션 실행, 다른 시각적인 것들을 멈추는데 사용
     */
    override fun onStop() {
        Log.i(TAG, "onStop() called")
        super.onStop()
    }

    /**
     * onDestroy() : onStop() 이후에 호출되는 생명주기 메소드
     * - 레이아웃과 개체들이 모두 소멸
     */

    override fun onDestroy() {
        Log.i(TAG, "onDestroy() called")
        super.onDestroy()
    }

    /**
     * onRestrat(): onStop() 상태에서 onStart() 상태로 바뀔 때
     * 중간에 호출되는 생명 주기 메소드
     */
    override fun onRestart() {
        Log.i(TAG, "onRestart() called")
        super.onRestart()
    }

    /**
     * onSaveInstanceState() : 앱이 (stop/destroy 이후) 다시 시작할 때
     * 필요한 데이터를 저장할 때 사용하는 메소드
     */
    override fun onSaveInstanceState(outState: Bundle?) {
        Log.i(TAG, "onSaveInstanceState()called")
        super.onSaveInstanceState(outState)

        //Bundle 객체에 데이터를 key-value 쌍으로 저장
        val msg = textView.text.toString()
        outState?.putString("MSG", msg)
        Log.i(TAG, "상태저장됨!@@@@@@@@@@@@@")
    }

    /**
     * onRestoreInstanceState() :
     * 저장한 데이터를 복원하는 시점에 호출되는 메소드
     */
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        Log.i(TAG, "onRestoreInstanceState() called")
        super.onRestoreInstanceState(savedInstanceState)

        val msg = savedInstanceState?.getString("MSG")
        textView.text = msg
        Log.i(TAG, "데이터 복원됨!@!@@@")
    }

}
