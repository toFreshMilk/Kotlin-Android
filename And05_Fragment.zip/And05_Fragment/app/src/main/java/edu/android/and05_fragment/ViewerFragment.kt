package edu.android.and05_fragment

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView



class ViewerFragment : Fragment() {

    private lateinit var imageView : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var rootView =  inflater.inflate(R.layout.fragment_viewer, container, false) as ViewGroup
        imageView = rootView.findViewById(R.id.imageView)
        return rootView
    }

    //이미지 리소스를 받아와서 이미지뷰에 이미지 변경
    fun setImage (resId : Int) {
        imageView.setImageResource(resId)
    }
}
