package edu.android.and05_fragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity(), ListFragment.ImageSelectionCallback {
    override fun onImageSelected(position: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        viewerFragment.setImage(images[position])
    }

    //프래그먼트를 미리 짜놓고 여기를 짜면 자동완성이 잘 된다
    private lateinit var listFragment: ListFragment
    private  lateinit var viewerFragment: ViewerFragment

    //이미지 배열 선언
    private var images = intArrayOf(R.drawable.dream01, R.drawable.dream02, R.drawable.dream03)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //프래그먼트를 관리하는 매니저 객체 선언
        val manager = supportFragmentManager

        // id로 각 프래그먼트 객체 찾아오기
        listFragment = manager.findFragmentById(R.id.listFragment) as ListFragment
        viewerFragment = manager.findFragmentById(R.id.listFragment) as ViewerFragment
    }

    //프래그먼트를 변경하는 함수
    fun onFragmentChanged(index : Int) {

        //
        //  supportFragmentManager.beginTransaction().replace(R.id.linearLayout, newFragment).commit()
    }
}
