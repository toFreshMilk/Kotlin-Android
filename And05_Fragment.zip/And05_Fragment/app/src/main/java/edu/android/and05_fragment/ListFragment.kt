package edu.android.and05_fragment


import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

//버튼 리스트 프래그먼트
class ListFragment : Fragment() {
    var callback : ImageSelectionCallback? = null

    //인터페이스 콜백
    interface ImageSelectionCallback {
        fun onImageSelected(position : Int)
    }

    /**
     * context
     * - 어플리케이션 환경에 대한 전역 정보 인터페이스
     */
    override fun onAttach(context: Context?) {
        //액티비티에 붙여서 정보를 가져온다.

        super.onAttach(context)
        // 형 변환이 가능하면 자동 형변환을 실행
        if(context is ImageSelectionCallback) {
            callback = context
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.fragment_list, container, false) as ViewGroup

        // 버튼에 대한 객체를 생성한다
        // 액티비티와는 다르게 findViewById 메서드로 찾아와야한다
        val button = rootView.findViewById<Button>(R.id.button)
        button.setOnClickListener {
            callback?.onImageSelected(0)
        }

        val button2 = rootView.findViewById<Button>(R.id.button2)
        button.setOnClickListener {
            callback?.onImageSelected(1)
        }

        val button3 = rootView.findViewById<Button>(R.id.button3)
        button.setOnClickListener {
            callback?.onImageSelected(2)
        }

        return rootView
    }


}
