package edu.android.and04_intent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        //메인에서 보낸 데이터 수신
        val extras = intent.extras
        if(extras != null) {
            val msg = extras.getString("key_extra")
            sTextView.text = msg
        } else {
            sTextView.text = " 번들없음"
        }


        sButton.setOnClickListener {
            fff()
            finish() // 현재 액티비티 종료
        }
    }

    private fun fff() {
        val intent = Intent(this, MainActivity :: class.java)
        val msg = sEditText.text.toString()
        intent.putExtra("key_extra", msg)

        startActivity(intent)
    }


}
