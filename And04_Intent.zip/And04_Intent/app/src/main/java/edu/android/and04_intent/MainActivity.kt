package edu.android.and04_intent

/**
 * 액티비티 간의 통신을 도와주는 Intent
 */

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mSendButton.setOnClickListener {
            startSecondActivity()
            finish() // 현재 액티비티 종료
        }


        //세컨드에서 보낸 데이터 수신
        val extras = intent.extras
        if(extras != null) {
            val msg = extras.getString("key_extra")
            mTextView.text = msg
        } else {
            mTextView.text = " 번들없음"
        }
    }

    private fun startSecondActivity() { // this는 메인 액티비티이고 메인에서 세컨드 액티비티로 보낸다.
        val intent = Intent(this, SecondActivity :: class.java)
        val msg = mEditText.text.toString()
        intent.putExtra("key_extra", msg)

        startActivity(intent)
    }
}
