package edu.android.mywebbrowser

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.email
import org.jetbrains.anko.sendSMS

class MainActivity : AppCompatActivity() {

    private val urlGoogle = "http://www.google.com" //url

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //객체에 적용되는 메소드를 {} 묶어서 실행
        // ex) list.add 할때 여러개를 한번에 실행하는 형태
        webView.apply {
            settings.javaScriptEnabled = true
            webChromeClient = WebChromeClient() // 웹뷰에 페이지를 표시하는 기능

        }

        //http:// 가 포함된 url을 전달하여 웹뷰에 페이지 로딩
        webView.loadUrl(urlGoogle)

        //urlEditText 버튼을 눌렀을 때 기능,
        //urlEditText.setOnEdi 까지입력하고 뜨는 애들중에 3번째
        urlEditText.setOnEditorActionListener { _, actionId, _ ->
            //인자 : 뷰, 액션ID, 이벤트

            //대문자로 되어있는 IME_ACTION_SEARCH 이런애들은 안드로이드에서 스태틱으로 제공하는 애들.
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { //검색버튼에 해당하는 상수와 비교하여 검색버튼이 눌렸는지 확인
                webView.loadUrl(urlEditText.text.toString())
                true
            } else {
                false
            }

        }

        /**
         * 자바 작성시 코드
         * new setOnEditorActionListner() {
        @override
        private boolean onEditerAction(TextView v, int actionId, KeyEvent event)
        }
         */
    }

    //뒤로가기 구현
    override fun onBackPressed() {
        if (webView.canGoBack()) { //최초페이지가 아닐 경우 등등
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu) //메뉴 리소스 지정
        //return super.onCreateOptionsMenu(menu)
        return true //메뉴가 있다고 인식
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.action_google, R.id.action_home -> {
                //, = or
                webView.loadUrl("http://www.google.com")
                return true
            }
            R.id.action_naver -> {
                //, = or
                webView.loadUrl("http://www.naver.com")
                return true
            }
            R.id.action_daum -> {
                //, = or
                webView.loadUrl("http://www.daum.com")
                return true
            }
            R.id.action_call -> {
                /**
                 * 암시적 인텐트
                 * 전화, 문자, 이메일 등에 데이터 전송
                 */
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:031-1223-1233") //전화 다이얼 오픈
                if (intent.resolveActivity(packageManager) != null) { //인텐트를 수행하는 액티비티가 있는지 검사
                    startActivity(intent) //있으면 수행
                }
                return true
            }

            R.id.action_send_text -> {
                sendSMS("02-1233-1233", webView.url)
                return true
            }

            R.id.action_email -> {
                email("asdf@naver.com", "제목이다", "내용이다")
                return true
            }


            return super.onOptionsItemSelected(item)-> {

            }

            // 처리하고자 하는 경우를 제외한 그 외의 경우에는 super 메소드를 호출하는 것이 보편적인 규칙
        }
    }
}
