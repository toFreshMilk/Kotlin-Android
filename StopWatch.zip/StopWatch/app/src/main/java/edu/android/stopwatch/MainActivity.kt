package edu.android.stopwatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {

    private var time = 0
    private var timerTask : Timer? = null;
    private var isRunning = false
    private var lap = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //시작 정지 버튼 기능 구현

        fab.setOnClickListener {
            isRunning = !isRunning

            if(isRunning) {
                start()
            } else {
                pasue()
            }
        }

        lapButton.setOnClickListener {
            recordLapTime()
        }

        //리셋
        resetFab.setOnClickListener {
            reset()
        }
    }

    private fun start() {
        fab.setImageResource(R.drawable.ic_pause_black_24dp)
        timerTask = timer(period = 10) {
            time ++
            val sec = time/60
            val milli = time%100
            runOnUiThread {
                setTextView.text = "$sec"
                milliTextView.text = "$milli"
            }
        }
    }

    private fun pasue() {
        fab.setImageResource(R.drawable.ic_play_arrow_black_24dp)
        //타이머 태스크는 스레드 이기때문에 여기서 잡힌다
        timerTask?.cancel()
    }

    private fun recordLapTime() {
        //동적으로 linearLayout에 뷰 추가하기
        // 최근의 랩 타임이 맨 위로 오게 작성

        val lapTime = this.time
        val textView = TextView(this)
        textView.text = "$lap LAP : ${lapTime /100}.${lapTime % 100}"

        //맨 위에 랩타임 추가
        lapLayout.addView(textView, 0)
        lap ++
    }

    private fun reset() {
        timerTask?.cancel()

        //모든 변수 초기화
        time = 0
        isRunning = false
        fab.setImageResource(R.drawable.ic_play_arrow_black_24dp)
        setTextView.text = "0"
        milliTextView.text = "00"

        //모든 랩타임 제거
        lapLayout.removeAllViews()
        lap = 1
    }
}
