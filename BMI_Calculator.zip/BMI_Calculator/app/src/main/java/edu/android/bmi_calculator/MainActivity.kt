package edu.android.bmi_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity


class MainActivity : AppCompatActivity() {

    private fun saveData(height : Int, weight : Int) {
        val pref = PreferenceManager.getDefaultSharedPreferences(this)

        //프리퍼런스 객체 생성, 프리퍼런스에 데이터를 담는 용도
        val editor = pref.edit()

        editor.putInt("KEY_HEIGHT", height)
            .putInt("KEY_WEIGHT", weight)
            .apply()
    }

    private fun loadData() {
        val pref = PreferenceManager.getDefaultSharedPreferences(this)
        val height = pref.getInt("KEY_HEIGHT", 0)
        val weight = pref.getInt("KEY_WEIGHT", 0) // 기본값을 0으로

        if( height != 0 && weight != 0) {
            heightEditText.setText(height.toString())
            weightEditText.setText(weight.toString())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //이전에 입력한 값 가져오기
        loadData()

        resultButton.setOnClickListener {
            /*
            // no anko
            val intent = Intent(this, ResultActivity :: class.java)
            intent.putExtra("height", heightEditText.text.toString())
            intent.putExtra("weight", weightEditText.text.toString())
            startActivity(intent)
            */

            //anko
            startActivity<ResultActivity>(
               "height" to heightEditText.text.toString(),
               "weight" to weightEditText.text.toString()
            )
        }
    }

}
