package edu.anroid.and08_socket

import android.os.Bundle
import android.os.Handler
import android.support.v7.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.net.ServerSocket
import java.net.Socket


const val TAG = "and08.MainActivity"
class MainActivity : AppCompatActivity() {
    private var handler = Handler()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            val data = editText.text.toString()

            Thread(Runnable { send(data) }).start()
        }

        button2.setOnClickListener { Thread(Runnable { startServer() }).start() }
    }

    private fun send(data: String) {
        try {
            val portNumber = 5002
            val sock = Socket("localhost", portNumber)
            printClientLog("소켓 연결함.")

            val outstream = ObjectOutputStream(sock.getOutputStream())
            outstream.writeObject(data)
            outstream.flush()
            printClientLog("데이터 전송함.")

            val instream = ObjectInputStream(sock.getInputStream())
            printClientLog("서버로부터 받음 : " + instream.readObject())
            sock.close()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }

    }

    private fun startServer() {
        try {
            val portNumber = 5002

            val server = ServerSocket(portNumber)
            printServerLog("서버 시작함 : $portNumber")

            while (true) {
                val sock = server.accept()
                val clientHost = sock.localAddress
                val clientPort = sock.port
                printServerLog("클라이언트 연결됨 : $clientHost : $clientPort")

                val inputStream = ObjectInputStream(sock.getInputStream())
                val obj = inputStream.readObject()
                printServerLog("데이터 받음 : $obj")

                val outputStream = ObjectOutputStream(sock.getOutputStream())
                outputStream.writeObject("$obj from Server.")
                outputStream.flush()
                printServerLog("데이터 보냄.")

                sock.close()
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
        }

    }

    private fun printClientLog(data: String) {
        Log.d(TAG, data)

        handler.post { textView.append(data + "\n") }

    }

    private fun printServerLog(data: String) {
        Log.d(TAG, data)

        handler.post { textView2.append(data + "\n") }
    }

}