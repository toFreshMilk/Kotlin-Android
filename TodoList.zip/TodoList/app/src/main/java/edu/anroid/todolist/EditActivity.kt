package edu.anroid.todolist

import android.annotation.SuppressLint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import io.realm.Realm
import io.realm.kotlin.createObject
import io.realm.kotlin.where
import kotlinx.android.synthetic.main.activity_edit.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.yesButton
import java.util.*

class EditActivity : AppCompatActivity() {

    var realm = Realm.getDefaultInstance() // 인스턴스 얻어오기
    val calendar : Calendar = Calendar.getInstance() // 날짜를 다룰 캘린더 객체

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        // 추가/수정 분기 처리
        // id == -1 : 추가 모드
        // id != -1 : 수정 모드
        val id = intent.getLongExtra("id", -1L)
        if(id == -1L){
            insertMode()
        } else {
            updateMode(id)
        }

        // 캘린더 뷰의 날짜를 선택했을 때 Calendar 객체에 설정
        calendarView.setOnDateChangeListener { view, year, month, dayOfMonth ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, month)
            calendar.set(Calendar.DAY_OF_YEAR, dayOfMonth)
        }
    }

    // 추가 모드 초기화
    @SuppressLint("RestrictedApi") // 검사를 제외할 항목 어노테이션
    private fun insertMode() {
        // 삭제 버튼 감추기
        deleteFab.visibility = View.GONE

        // 완료 버튼을 클릭하면 추가
        doneFab.setOnClickListener { insertTodo() }
    }

    // 수정 모드 초기화
    private fun updateMode(id : Long){
        // id에 해당하는 객체를 화면에 표시
        val todo = realm.where<Todo>().equalTo("id", id).findFirst()!!
        todoEditText.setText(todo.title)
        calendarView.date = todo.date

        // 완료 버튼을 클릭하면 수정
        doneFab.setOnClickListener {
            updateTodo(id)
        }

        // 삭제 버튼을 클릭하면 수정
        deleteFab.setOnClickListener {
            deleteTodo(id)
        }

    }



    override fun onDestroy() {
        super.onDestroy()
        realm.close()  // 인스턴스 해제
    }

    // 할 일 생성
    private fun insertTodo() {
        realm.beginTransaction()        // 트랜잭션 시작

        val newItem = realm.createObject<Todo>(nextId())  // 새 객체 생성
        // 값 설정
        newItem.title = todoEditText.text.toString()  // todoEditext 값 저장
        newItem.date = calendar.timeInMillis   // 날짜 정보 설정

        realm.commitTransaction()       // 트랜잭션 종료 반영

        // 다이얼로그 표시
        alert("내용이 추가되었습니다."){
            yesButton { finish() }
        }.show()
    }

    // 다음 id를 반환
    private fun nextId() : Int {
        // Realm은 기본키 자동 증가 기능을 지원하지 않음
        // 따라서 메소드로 생성

        val maxId = realm.where<Todo>().max("id")
        // realm.where<>() :Todo테이블의 모든 값을 얻어옴
        // max는 현재 id 중 가장 큰 값을 얻어옴

        if (maxId != null){
            return maxId.toInt() + 1
        }
        return 0
    }

    // 할 일 수정
    private fun updateTodo(id : Long){
        realm.beginTransaction() // 트랜잭션 시작

        val updateItem = realm.where<Todo>().equalTo("id", id).findFirst()!!
        // 테이블의 모든 값을 얻어와서 "id" 컬럼에 id값이 있으면 findFirst() 메소드로 첫 번째 데이터를 반환

        // 값 수정
        updateItem.title = todoEditText.text.toString()
        updateItem.date = calendar.timeInMillis

        realm.commitTransaction()   // 트랜잭션 종료 반영

        // 다이얼로그 표시
        alert("내용이 변경되었습니다."){
            yesButton { finish() }
        }.show()
    }

    // 할 일 삭제
    private fun deleteTodo(id : Long){
        realm.beginTransaction()
        val deleteItem = realm.where<Todo>().equalTo("id", id).findFirst()!!

        // 삭제할 객체
        deleteItem.deleteFromRealm()   // 삭제
        realm.commitTransaction()

        alert("내용이 삭제되었습니다."){
            yesButton { finish() }
        }.show()
    }


}
