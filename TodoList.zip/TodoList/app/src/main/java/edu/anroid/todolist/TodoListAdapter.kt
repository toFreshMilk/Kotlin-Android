package edu.anroid.todolist

import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import io.realm.OrderedRealmCollection
import io.realm.RealmBaseAdapter

class TodoListAdapter(realmResult : OrderedRealmCollection<Todo>)
    : RealmBaseAdapter<Todo>(realmResult){

    // 뷰 홀더 패턴은 한 번 만들어둔 뷰를 최대한 재활용하여 성능을 높여주는 방법
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        val vh : ViewHolder
        val view : View

        // convertView 객체가 없으면 뷰홀더를 새로 생성
        // convertView 객체가 있으면 view에 저장
        if(convertView == null){
            view = LayoutInflater.from(parent?.context)
                .inflate(R.layout.item_todo, parent, false)
            vh = ViewHolder(view)
            view.tag = vh
        } else {
            view = convertView
            vh = view.tag as ViewHolder
        }

        if(adapterData != null){ // 데이터가 없다면 해당 위치에 데이터를 저장
            val item = adapterData!![position]
            vh.textTextView.text = item.title
            vh.dataTextView.text = DateFormat.format("yyyy/MM/dd", item.date)
        }

        return view
    }

    override fun getItemId(position: Int): Long {
        if(adapterData != null){
            return adapterData!![position].id
        }
        return super.getItemId(position)
    }

}

// 클래스 먼저 만들것
class ViewHolder(view : View){
    val dataTextView : TextView = view.findViewById(R.id.text1)
    val textTextView : TextView = view.findViewById(R.id.text2)
}