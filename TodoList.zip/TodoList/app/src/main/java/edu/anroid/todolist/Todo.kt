package edu.anroid.todolist

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class Todo ( // Realm을 사용하는 클래스에 open 키워드 추가
    @PrimaryKey var id : Long = 0, // 기본키, 중복을 허용하지 않음
    var title : String = "",
    var date : Long  =0
) : RealmObject() { // RealmObject 클래스를 상속

}

