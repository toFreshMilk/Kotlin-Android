package edu.anroid.todolist

import android.app.Application
import io.realm.Realm

// 앱을 실행하면 가장 먼저 실행되는 클래스
// Manifest 파일 수정
class MyApplication : Application() {   // Application 클래스를 상속
    override fun onCreate() {
        super.onCreate()
        Realm.init(this) // 초기화
    }
}