package edu.android.and07_service

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

/**
 * 서비스
 * - 사요앚와 상호작용하지 않고 장기 실행 작업을 수행하거나
 *   다른 어플리케이션을 사용하기 위한 기능을 제공하는 응용프로그램 요소
 * - 다른 어플리케이션 객체와 마찬가지로 호스팅 프로세스의 메인 스레드에서 실행
 * - 음악 백그라운드 등 백그라운드 서비스를 실행하려면 자체적으로 스레드를 생성해야함
 * - 생명주기가 존재한다
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //서비스로 인텐트 보내기
        button.setOnClickListener {
            val name = editText.text.toString()
            val intent = Intent(this@MainActivity, MyService::class.java)
            intent.putExtra("command", "show")
            intent.putExtra("name", name)

            //보낸다
            startService(intent)
        }

        //서비스로부터 받은 인텐트 저장
        val passedIntent = intent //public, 떠돌아다니는 인텐트를 가져옴

        //인텐트 실행
        processIntent(passedIntent)
    }
    // 서비스로터 받은 인텐트 구성
    private fun processIntent(intent: Intent?) {
        if (intent != null) {
            val command = intent.getStringExtra("command")
            val name = intent.getStringExtra("name")

            Toast.makeText(
                this, "command : $command, name : $name", Toast.LENGTH_LONG
            ).show()
        }
    }
}
