package edu.android.and07_service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import java.lang.Exception
import kotlin.system.exitProcess

const val TAG = "MyService"
class MyService : Service() {

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "onCreate() 호출됨")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        //인텐트를 받아올 때까지 기다린다
        Log.d(TAG, "onStartCommand 호출됨")

        //인텐트 객체가 없으면
        if(intent == null) {
            return START_STICKY // 인텐트 값을 널로 초기화 시켜 재시작
        } else {
            processCommand(intent)
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun processCommand(intent: Intent) {
        val command = intent.getStringExtra("command")
        val name = intent.getStringExtra("name")
        Log.d(TAG, "command : $command, name : $name")

        //쓰레드 작업
        for(i in 0..4) {
            try {
                Thread.sleep(1000)
            } catch (e:Exception) {
                println(e)
            }
            Log.d(TAG, "watting $i seconds")
        }

        /**
         * Task
           - 어플리케이션에서 실행되는 액티비티를 보관하고 관리하며 Stack 형태의 연속된 Activity로 이루어짐
           - Flag를 사용하여 Task내 액티비티의 흐름을 제어
         */

        //메인 액티비티에 보내는 인텐트 applicationContext에서 메인액티비티로 간다
        val showIntent = Intent(applicationContext, MainActivity::class.java)
        showIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or // History stack 내 이 액티비티가 새로운 태스크로 실행됨
            Intent.FLAG_ACTIVITY_SINGLE_TOP or //History stack의 맨 위에 이 액티비티가 이미 실행될 경우 실행되지 않음
            Intent.FLAG_ACTIVITY_CLEAR_TOP // History stack에 호출하는 액티비티가 존재할 경우
                                            // 해당액티비티를 최상으로 올리면서, 그 위에 존재하는 액티비티는 삭제
        )
        showIntent.putExtra("command", "show")
        showIntent.putExtra("name", "$name from Service")
        startActivity(showIntent)
    }

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }
}
