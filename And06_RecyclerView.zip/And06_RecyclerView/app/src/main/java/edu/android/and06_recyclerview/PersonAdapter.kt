package edu.android.and06_recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PersonAdapter : RecyclerView.Adapter<PersonAdapter.ViewHolder> (), OnPersonItemClickListener {
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(viewGroup.context)
        val itemView = inflater.inflate(R.layout.person_item, viewGroup, false)
        return ViewHolder(itemView, this) //OnPersonItemClickListener 를 상속받아 구현
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val item = items[position]
        viewHolder.setItem(item)
    }

    override fun onItemClick(holder: ViewHolder, view: View, position: Int) {
        listener?.onItemClick(holder, view, position)
    }

    fun setItems(items : ArrayList<Person>) {
        this.items = items
    }

    fun getItems(position: Int) : Person {
        return items[position]
    }

    fun setOnItemClickListener(listener: OnPersonItemClickListener) {
        this.listener = listener
    }

    private var items = ArrayList<Person> ()
    private var listener : OnPersonItemClickListener? = null

    inner class ViewHolder(itemView : View, listener : OnPersonItemClickListener?)
        : RecyclerView.ViewHolder(itemView) { //메인 엑티비티에 있는 리사이클러뷰
        private var textView = itemView.findViewById<TextView>(R.id.textView)
        private var textView2 = itemView.findViewById<TextView>(R.id.textView2)

        init {
            itemView.setOnClickListener{
                view ->
                listener?.onItemClick(this@ViewHolder, view, position)
            }
        }
        fun setItem(item : Person) {
            textView.text = item.name
            textView2.text = item.mobile
        }
    }
}