package edu.android.and06_recyclerview

object PersonDAO {
    private lateinit var personList: List<Person>

    fun makePersonList(pNum : Int) : List<Person> {
        //스마트 캐스트, 이미 위에서 Person 이라고 타입명시해줌
        personList = ArrayList()
        for ( i in 1..pNum) {
            personList += Person("이름$i", "01022323232$i")
        }
        return personList
    }
}