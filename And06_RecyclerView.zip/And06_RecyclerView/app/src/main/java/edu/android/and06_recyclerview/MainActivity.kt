package edu.android.and06_recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PersonAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        val layoutManager = GridLayoutManager(this, 2)

        recyclerView.layoutManager = layoutManager

        adapter = PersonAdapter()
        val personList = PersonDAO.makePersonList(20)
        adapter.setItems(personList as ArrayList<Person>) //personList가 List여서 형변환을 해줌

        recyclerView.adapter = adapter

        // OnPersonItemClickListener 인터페이스를 구현한 익명 클래스 사용
        adapter.setOnItemClickListener(object : OnPersonItemClickListener {
            override fun onItemClick(holder: PersonAdapter.ViewHolder, view: View, position: Int) {
                val item = adapter.getItems(position)
                Toast.makeText(applicationContext, "아이템 선택됨 : " + item.name, Toast.LENGTH_LONG).show()
            }
        })
    }
}
