package edu.android.and06_recyclerview

data class Person (var name : String, var mobile : String) {

}